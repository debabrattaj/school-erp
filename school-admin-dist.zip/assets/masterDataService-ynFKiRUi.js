import{A as s}from"./index-Cgjy5tsf.js";async function n(a){return(await s.get(`/master-data/${a}`)).data.values||[]}async function o(a){return(await n(a)).map(e=>e.value)}export{o as g};
